  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myempmgmtapp.pojo;


public class EmpPojo {
     private int empno;
    private String name;
    private double sal;
    public EmpPojo()
    {
        
    }
    
     public EmpPojo(int empno, String name, double sal) {
        this.empno = empno;
        this.name = name;
        this.sal = sal;
    }
 public int getEmpno() {
        return empno;
    }

    public void setEmpno(int empno) {
        this.empno = empno;
    }

    public String getName() {
        return name;
    }

   
    public void setName(String name) {
        this.name = name;
    }

    public double getSal() {
        return sal;
    }

    public void setSal(double sal) {
        this.sal = sal;
    }
   
}
